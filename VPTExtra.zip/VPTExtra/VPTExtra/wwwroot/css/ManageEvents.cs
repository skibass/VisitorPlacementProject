﻿namespace VPTExtra.wwwroot.css
{
    public class ManageEvents
    {
    }
}
